const sumar = require('./sumar');
const multiplicar = require('./multiplicar')

console.log(multiplicar.multiplica(5,6));

console.log(sumar.sumarDosMasDos());

console.log(sumar.suma(6, 9));